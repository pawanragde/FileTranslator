﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTranslator
{
    class Common
    {
        public static Type GetDotNETType(string s)
        {
            Type t = null;
            switch (s)
            {
                case "int":
                    t = typeof(int);
                    break;
                case "double":
                    t = typeof(Double);
                    break;
                default:
                    t = typeof(string);
                    break;
            }
            return t;
        }
    }
}
