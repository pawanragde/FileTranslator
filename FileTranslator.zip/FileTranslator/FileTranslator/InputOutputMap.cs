﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace FileTranslator
{
    public class InputOutputMap
    {
        [XmlRoot("conversion")]
        public class Conversion
        {
            [XmlElement("input")]
            public Input Input { get; set; }

            [XmlElement("output")]
            public Output Output { get; set; }

            [XmlElement("mapping")]
            public Mapping Mapping { get; set; }
        }
        public class Input
        {
            [XmlAttribute]
            public string hasHeader { get; set; }

            [XmlAttribute]
            public string format { get; set; }

            [XmlElement("column")]
            public List<InputColumn> InputColumns { get; set; }

        }
        public class Output
        {
            [XmlAttribute]
            public string format { get; set; }

            [XmlElement("column")]
            public List<OutputColumn> OutputColumns { get; set; }

        }
        public class Mapping
        {
            [XmlElement("map")]
            public List<Map> Maps { get; set; }

        }
        public class InputColumn
        {
            [XmlAttribute]
            public string type { get; set; }

            [XmlAttribute]
            public string name { get; set; }

            [XmlAttribute]
            public int length { get; set; }
        }
        public class OutputColumn
        {
            [XmlAttribute]
            public string type { get; set; }

            [XmlAttribute]
            public string name { get; set; }

        }
        public class Map
        {
            [XmlAttribute]
            public string dest { get; set; }

            [XmlAttribute]
            public string source { get; set; }
        }
    }
}
