﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Dynamic;

namespace FileTranslator
{
    class Worker
    {
        public static void RunWorkflow()
        {
            string path = Directory.GetCurrentDirectory() + @"..\..\..\mapping1.xml";
            string inputFilePath = Directory.GetCurrentDirectory() + @"..\..\..\constituents.csv";
            string outputFilePath = Directory.GetCurrentDirectory() + @"..\..\..\constituents.xml";

            InputOutputMap.Conversion conversion = ExtractMapping(path);

            var inputColumnsFromMapping = conversion.Input.InputColumns.ToDictionary(i => i.name);

            IEnumerable<DynamicProperty> inputFileProperties = inputColumnsFromMapping.Select(property => new DynamicProperty(property.Key, Common.GetDotNETType(property.Value.type))).ToList();

            #region R&D using expando objects
            /*
            List<dynamic> dynamicList = null;

            using (var reader = new StreamReader(inputFilePath))
            {
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    dynamicList = csv.GetRecords<dynamic>().ToList();
                }
            }
            IDictionary<string, object> propertyValues = dynamicList.First();

            bool inputFileFormatValidate = false;
            foreach (var property in propertyValues.Keys)
            {
                inputFileFormatValidate = !inputFileProperties.Where(p => p.Name == property).Any();

                if (inputFileFormatValidate)
                    throw new Exception("FileFormat does not match expected schema.");
            }
            */
            #endregion

            DataTable dt = LoadFileToDataTable(inputFilePath);

            ValidateInputFormat(inputColumnsFromMapping, dt);

            GenerateOutputFile(conversion, dt, outputFilePath);

        }

        private static void GenerateOutputFile(InputOutputMap.Conversion conversion, DataTable dt, string outputFilePath)
        {
            foreach (DataColumn column in dt.Columns)
            {
                var newColumnName = conversion.Mapping.Maps.Where(m => m.source == column.ColumnName).First().dest;
                column.ColumnName = newColumnName;
            }
            dt.WriteXml(outputFilePath);
        }

        private static void ValidateInputFormat(Dictionary<string, InputOutputMap.InputColumn> inputColumnsFromMapping, DataTable dt)
        {
            var fileColumnNames = dt.Columns.Cast<DataColumn>().Select(x => x.ColumnName);

            var unexpectedColumms = fileColumnNames.Except(inputColumnsFromMapping.Keys);
            if (unexpectedColumms.Any())
                throw new Exception("Unexpected columns in file.");
            //TODO: Match types on columns.
        }

        private static DataTable LoadFileToDataTable(string inputFilePath)
        {
            var dt = FileIO.GetDataTableFromCSVFile(inputFilePath);
            dt.TableName = "Constituents"; //needed to write to xml
            return dt;
        }

        private static InputOutputMap.Conversion ExtractMapping(string path)
        {
            string xmlInputData = FileIO.ReadAllText(path);

            InputOutputMap.Conversion conversion = XMLHelper.Deserialize<InputOutputMap.Conversion>(xmlInputData);
            return conversion;
        }
    }
}
